

function Sobre() {
    return (
      <div>
        Sobre
      </div>
    );
}
  
  
  export default Sobre;
  
  

import {Link} from 'react-router-dom';

function Home() {
    return (
      <div>
        Home
        <Link to="/sobre"> Sobre </Link>
      </div>
    );
}
  
  
  export default Home;
  
  
